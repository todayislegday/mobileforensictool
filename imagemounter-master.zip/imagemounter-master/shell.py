#!/usr/bin/env python
# backwards compatibility
from imagemounter.cli.shell import main

main()
