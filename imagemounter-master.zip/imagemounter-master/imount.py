#!/usr/bin/env python
# backwards compatibility
from imagemounter.cli.imount import main

main()