import logging

logger = logging.getLogger("imagemounter")
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler())
